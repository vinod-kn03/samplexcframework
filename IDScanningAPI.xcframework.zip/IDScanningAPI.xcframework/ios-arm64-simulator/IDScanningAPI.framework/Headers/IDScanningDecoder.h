//
//  IDScanningDecoder.h
//  IDScanningAPI
//
//  Created by H454944 on 31/08/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface IDScanningDecoder : NSObject

-(void)activateBlinkID;
@end

NS_ASSUME_NONNULL_END

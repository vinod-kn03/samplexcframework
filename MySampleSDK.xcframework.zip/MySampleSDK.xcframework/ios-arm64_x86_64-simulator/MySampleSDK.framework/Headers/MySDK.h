//
//  MySDK.h
//  MySampleSDK
//
//  Created by H454944 on 21/07/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MySDK : NSObject

-(int)multiply:(int)a with:(int)b;

@end

NS_ASSUME_NONNULL_END
